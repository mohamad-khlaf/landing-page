<div style="display: none;">
	<span class="input-group-addon" id="calImg">
		<span> <i class="fa fa-calendar" aria-hidden="true"></i> </span>
	</span>
</div>
					
<div class="col-sm-6 col-xs-12 form-group">
	<div class="input-group">
		<input  type="text" id="ContentPlaceHolder1_PageData_ucZawga_PersonDataControl1_ucBirthDate_pickCalHj" class="pickCalHj form-control" readonly="readonly" placeholder="هجري" />
	</div>
</div>

<div class="col-sm-6 col-xs-12 form-group">
	<div class="input-group">
		<input  type="text" id="ContentPlaceHolder1_PageData_ucZawga_PersonDataControl1_ucBirthDate_pickCalGer" class="pickCalGer form-control" readonly="readonly" placeholder="ميلادي" />
	</div>
</div>

<!-- هذان الحقل استغلا و امورهما تمام بدون الحاجة ل الاكواد في الاعلى  -->
اي دي لا تحذف لانه هو المروبط ب ملف sss.js
<input  type="text" id="ContentPlaceHolder1_PageData_ucZawga_PersonDataControl1_ucBirthDate_pickCalHj" class="pickCalHj form-control" readonly="readonly" placeholder="هجري" />
<input  type="text" id="ContentPlaceHolder1_PageData_ucZawga_PersonDataControl1_ucBirthDate_pickCalGer" class="pickCalGer form-control" readonly="readonly" placeholder="ميلادي" />

	
						
		<!-- End Calender  -->
		<link rel="stylesheet" type="text/css" href="./calender-css-js/ummalqura.calendars.picker.css" />
		<script type="text/javascript" src="./calender-css-js/jquery-3.6.1.min.js"></script>
		<script type="text/javascript" src="./calender-css-js/jquery.calendars.js"></script>
		<script type="text/javascript" src="./calender-css-js/jquery.plugin.js"></script>
		<script type="text/javascript" src="./calender-css-js/jquery.calendars.plus.js"></script>
		<script type="text/javascript" src="./calender-css-js/jquery.calendars.picker.js"></script>
		<script type="text/javascript" src="./calender-css-js/jquery.calendars.picker-ar.js"></script>
		<script type="text/javascript" src="./calender-css-js/jquery.calendars.ummalqura.js"></script>
		<script type="text/javascript" src="./calender-css-js/jquery.calendars.ummalqura-ar.js"></script>
		<script type="text/javascript" src="./calender-css-js/calendar-convert.js"></script>
		<script type="text/javascript" src="./calender-css-js/sss.js"></script>
		<!-- End Calender  -->