<?php 
     $connect = mysqli_connect("localhost", "ukquqlmy_support_search", "d(0E%bDzBcR2", "ukquqlmy_support_search");
    // $connect = mysqli_connect("localhost", "root", "", "dashboard_5");
?>