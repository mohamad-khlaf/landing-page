// ---------------- Start move data from Inputs To Contracts ----------------
let allInputs = document.querySelectorAll("input");
allInputs.forEach(function(input) {
    input.addEventListener("input", function() {
        let className = input.getAttribute("data-class");
        document.querySelectorAll( `.${className}` ).forEach( (ele) => ele.innerHTML = input.value);

    })
})
// ---------------- End move data from Inputs To Contracts ----------------

// ---------------- Start move data from Inputs type Select To Contracts ----------------
document.querySelectorAll("select").forEach( select => {
    select.addEventListener("input", function() {
        let className = this.getAttribute('data-class');
        let valueSelect = this.value;
        // console.log(valueSelect);
        // console.log(className);
        document.querySelectorAll( `.${className}` ).forEach( (ele) => ele.innerHTML = valueSelect);
    });
});
// ---------------- Start move data from Inputs type Select To Contracts ----------------


// ---------------- Start show hide contract ----------------
let contract = document.querySelector(".contract");
let submitBtnsContainer = document.querySelector(".submit-btns-container");
let showContractBtn = document.querySelector(".show-contract");

showContractBtn.addEventListener("click", function(e) {
    e.preventDefault();
    contract.classList.toggle('show');
    if (contract.classList.contains('show')) {
        showContractBtn.innerHTML = ' إخفاء العقد و تعديل بعض البيانات <i class="fa-solid fa-eye-slash"></i>' ;
        submitBtnsContainer.querySelector('.submit-btn').value = 'العقد تمام وأرغب في التسجيل';
        submitBtnsContainer.classList.add("fixes-btns");
    } else {
        showContractBtn.innerHTML = 'مشاهدة العقد  <i class="fa-solid fa-eye"></i>';
        submitBtnsContainer.querySelector('.submit-btn').value = 'تسجيل';
        submitBtnsContainer.classList.remove("fixes-btns");

    }
})
// ---------------- Start show hide contract ----------------

// ---------------- End Start print  ----------------
document.querySelector(".btn-print").addEventListener("click", (b) => window.print()); 
// ---------------- End Start print ----------------
