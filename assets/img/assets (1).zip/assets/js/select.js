// ---------------- Start move data from Inputs To Contracts ----------------
let allInputs = document.querySelectorAll("input");
allInputs.forEach(function(input) {
    input.addEventListener("input", function() {
        let className = input.getAttribute("data-class");
        document.querySelectorAll( `.${className}` ).forEach( (ele) => ele.innerHTML = input.value);

    })
})
// ---------------- End move data from Inputs To Contracts ----------------

// ---------------- Start move data from Inputs type Select To Contracts ----------------
document.querySelectorAll("select").forEach( select => {
    select.addEventListener("input", function() {
        let className = this.getAttribute('data-class');
        let valueSelect = this.value;
        console.log(valueSelect);
        console.log(className);
        document.querySelectorAll( `.${className}` ).forEach( (ele) => ele.innerHTML = valueSelect);
    });
});
// ---------------- Start move data from Inputs type Select To Contracts ----------------

// ---------------- Start  ----------------
let optionLevelOne = `
    <option value="0" selected>أختر</option>
    <option value="رياض الأطفال" >رياض الأطفال </option>
    <option value="المرحلة الابتدائية">المرحلة الابتدائية</option>
    <option value="المرحلة المتوسطة" 		  >المرحلة المتوسطة</option>
    <option value="المرحلة الثانوية" 		  >المرحلة الثانوية</option>                      
`;
let optionLevelTow = `
    <option value="0" selected>أختر</option>
    <option value="المرحلة الابتدائية">المرحلة الابتدائية</option>
    <option value="المرحلة المتوسطة" 		  >المرحلة المتوسطة</option>
    <option value="المرحلة الثانوية" 		  >المرحلة الثانوية</option>                      
`;
let optionLevelThree = `
    <option value="0" selected>أختر</option>
    <option value="رياض الأطفال" >رياض الأطفال </option>
    <option value="المرحلة الابتدائية">المرحلة الابتدائية</option>              
`;
let optionLevelFour = `
    <option value="0" selected>أختر</option>
    <option value="المرحلة الابتدائية">المرحلة الابتدائية</option>         
`;

let complexGroupOne = `
    <option value="0" selected>أختر</option>
    <option  value="1" >مجمع البنات الجديد</option>
    <option  value="2">ابتدائية بديعة بنين</option>
    <option  value="3">مجمع العريجاء بنين</option>
    <option  value="4">مجمع نمار بنين</option>
`;
let complexGroupTow = `
    <option value="0" selected>أختر</option>
    <option  value="1" >مجمع البنات الجديد</option>
    <option  value="4">مجمع نمار بنين</option>
`;
let complexGroupThree = `
    <option value="0" selected>أختر</option>
    <option  value="1" >مجمع البنات الجديد</option>    
`;


let pathValue = 1;

document.querySelectorAll("select").forEach(function(select) {
    select.addEventListener("input", function() {
        let selectType = select.getAttribute('data-class');
        let valueOfInput = select.value;
        if(selectType == 'path-data') {
            pathSelected(valueOfInput);
        }
        if (selectType == 'complex-data') {
            complexSelected(valueOfInput);
        }
    });
});











function pathSelected(valueOfInput) {
    console.log(valueOfInput);
    // تحديد  في العقد المسار المختار
    // تحديد المحمات المتاحة بحسب المسار المختار 
    let complexSelectTag = document.querySelector(".complex-class-select");
    let contractTag = document.querySelector(".path-data");
    console.log("-------");
    console.log(valueOfInput);
    console.log("-------");

    if (valueOfInput == 1) {
        complexSelectTag.innerHTML = complexGroupOne;
        // contractTag.innerHTML = 'مجمع البنات الجديد';
        contractTag.innerHTML = 'مسار التعليم العام';

    } else if (valueOfInput == 2) {
        complexSelectTag.innerHTML = complexGroupOne;
        // contractTag.innerHTML = 'ابتدائية بديعة';
        contractTag.innerHTML = 'تحفيظ القراءن';

    } else if (valueOfInput == 3) {
        // contractTag.innerHTML = 'مجمع العويجاء ';
        contractTag.innerHTML = 'مسار الدبلوما الأمريكية';
        complexSelectTag.innerHTML = complexGroupTow;

    } else if (valueOfInput == 4) {
        complexSelectTag.innerHTML = complexGroupThree;
        // contractTag.innerHTML = 'مجمع نمار ';
        contractTag.innerHTML = 'مسار الطفولة المبكرة';
        document.querySelector('.pathchildrn-class-complex-banat').style.display = "flex";
    }
    pathValue = valueOfInput;

    if (!pathValue == 4 ) {
        document.querySelector('.pathchildrn-class-complex-banat').style.display = "none";
    }
}










function complexSelected(valueOfInput) {
    let levelOptionTag = document.querySelector('.school-level');
    let ccccccc = document.querySelector('.complex-data-title');

    if (pathValue == 1 || pathValue == 2 && valueOfInput == 1) {
        levelOptionTag.innerHTML = optionLevelOne;
        ccccccc.innerHTML = 'مجمع البنات الجديد';

    };
    if (pathValue == 1 || pathValue == 2 && valueOfInput == 2) {
        levelOptionTag.innerHTML = optionLevelFour;
        ccccccc.innerHTML = 'ابتدائية البديعة بنين';
    };
    if (pathValue == 1 || pathValue == 2 && valueOfInput == 3) {
        levelOptionTag.innerHTML = optionLevelTow;
        ccccccc.innerHTML = 'مجمع العريجاء بنين ';
    };
    if (pathValue == 1 || pathValue == 2 && valueOfInput == 4) {
        levelOptionTag.innerHTML = optionLevelTow;
        ccccccc.innerHTML = 'مجمع نمار بنين ';

    }

    if (pathValue == 3 && valueOfInput == 1) {
        levelOptionTag.innerHTML = optionLevelThree;
        ccccccc.innerHTML = 'مجمع البنات الجديد';

    };
    if (pathValue == 3 && valueOfInput == 4) {
        levelOptionTag.innerHTML = optionLevelTow;
        // contractTag.innerHTML = 'مجمع نمار بنين ';
    };

    if (pathValue == 4 && valueOfInput == 1) {
        levelOptionTag.innerHTML = optionLevelFour;
        ccccccc.innerHTML = 'مجمع البنات الجديد';

        // و اظهار الصف 
        document.querySelector('.pathchildrn-class-complex-banat').style.display = "flex";

    };

    if (!pathValue == 4 && valueOfInput == 1) {
        document.querySelector('.pathchildrn-class-complex-banat').style.display = "none";
    }
    console.log(pathValue + "_" + valueOfInput);


}
// ---------------- End  ----------------























// ---------------- Start show hide contract ----------------
let contract = document.querySelector(".contract");
let submitBtnsContainer = document.querySelector(".submit-btns-container");
let showContractBtn = document.querySelector(".show-contract");

showContractBtn.addEventListener("click", function(e) {
    e.preventDefault();
    contract.classList.toggle('show');
    if (contract.classList.contains('show')) {
        showContractBtn.innerHTML = ' إخفاء العقد و تعديل بعض البيانات <i class="fa-solid fa-eye-slash"></i>' ;
        submitBtnsContainer.querySelector('.submit-btn').value = 'العقد تمام وأرغب في التسجيل';
        submitBtnsContainer.classList.add("fixes-btns");
    } else {
        showContractBtn.innerHTML = 'مشاهدة العقد  <i class="fa-solid fa-eye"></i>';
        submitBtnsContainer.querySelector('.submit-btn').value = 'تسجيل';
        submitBtnsContainer.classList.remove("fixes-btns");

    }
})
// ---------------- Start show hide contract ----------------








// ---------------- End Start print  ----------------
document.querySelector(".btn-print").addEventListener("click", (b) => window.print()); 
// ---------------- End Start print ----------------

let submit = document.querySelector('input[type="submit"]');


submit.addEventListener('click', function() {
    console.log("click submit");
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'https://mobile.net.sa/sms/gw/?userName=MyUser&userPassword=MyPass&numbers=966555525555&userSender=Mobile.Sa&msg=00770065006C0063006F006D006500200074006F0020006D006F00620069006C0065002E006E00650074002E00730061&By=standard&YesRepeat=1');
    xhr.send();
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            const data = xhr.response;
            console.log(data);
        } else {
            console.log(`Error: ${xhr.status}`);
            console.log(xhr.responseText);
        }
        console.log(xhr.readyState);
        console.log(xhr.status);
    }

})