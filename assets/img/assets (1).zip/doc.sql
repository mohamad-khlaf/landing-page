


CREATE TABLE `regerster` (
  `id`                        int(11)                NOT NULL,
  `educational_path`          varchar(255)           NOT NULL,
  `complex_name`              varchar(255)           NOT NULL,
  `educational_level`         varchar(255)           NOT NULL,
  `educational_class`         varchar(255)           NOT NULL,
  `transport_type`            varchar(255)           NOT NULL,
  `full_student_name`         varchar(255)           NOT NULL,
  `student_id_num`            varchar(255)           NOT NULL,
  `country`                   varchar(255)           NOT NULL,
  `birthday`                  varchar(255)           NOT NULL,
  `birthday_hijry`            varchar(255)           NOT NULL,
  `birthday_city`             bigint                 NOT NULL,
  `study_certificate`         varchar(255)           NOT NULL,
  `study_stutas`              varchar(255)           NOT NULL,
  `illnesses`                 tinytext               NOT  NULL,
  `parent_name`               tinytext               NOT  NULL,
  `parent_nationalty`         varchar(255)           NOT NULL,
  `reserve1_relation_parent`  varchar(255)           NOT NULL,
  `id_patent_type`            varchar(255)           NOT NULL,
  `id_source_parent`          varchar(255)           NOT NULL,
  `parent_id_num`             varchar(255)           NOT NULL,
  `id_finish_date`            varchar(255)           NOT NULL,
  `parent_job`                varchar(255)           NOT NULL,
  `parent_job_address`        varchar(255)           NOT NULL,
  `parent_email`              varchar(255)           NOT NULL,
  `neighborhood_address`      varchar(255)           NOT NULL,
  `main_street`               varchar(255)           NOT NULL,
  `sub_street`                varchar(255)           NOT NULL,
  `house_num`                 varchar(255)           NOT NULL,
  `next_to`                   varchar(255)           NOT NULL,
  `house_phone`               varchar(255)           NOT NULL,
  `reserve_name_1`            varchar(255)           NOT NULL,
  `reserve_relation_1`        varchar(255)           NOT NULL,
  `reserve_relation_phone_1`  varchar(255)           NOT NULL,
  `reserve_name_2`            varchar(255)           NOT NULL,
  `reserve_relation_2`        varchar(255)           NOT NULL,
  `reserve_relation_phone_2`  varchar(255)           NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `regerster`ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `regerster`
  MODIFY `id` int NOT NULL AUTO_INCREMENT; 
  COMMIT;
