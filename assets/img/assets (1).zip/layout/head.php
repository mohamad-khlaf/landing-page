
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Start google Font  -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<!-- End google Font  -->


<!-- Start fivicon  -->
<link rel="apple-touch-icon" sizes="180x180" 	href="./assets/imgs/fivicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="./assets/imgs/fivicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="./assets/imgs/fivicon/favicon-16x16.png">
<link rel="manifest" 							href="./assets/imgs/fivicon/site.webmanifest">
<link rel="mask-icon" 							href="./assets/imgs/fivicon/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" 						href="./assets/imgs/fivicon/favicon.ico">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="msapplication-config" content="./assets/imgs/fivicon/browserconfig.xml">
<meta name="theme-color" content="#ffffff">
<!-- End fivicon  -->
