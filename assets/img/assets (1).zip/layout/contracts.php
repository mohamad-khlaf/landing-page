
		<main class="contract " id="contract" dir="rtl">
			<section class="main-forms">
				<div class="container">
					<header class="row txt-center justify-content-between align-items-center border-bottom border-primary border-3 mb-4 pb-2 header-contarct">
						<div class="col-4">
							<h1>شركة دار الشوامخ التعليمية</h1>
							<p class="complex-data-title">$complex_name</p>
						</div>
						<div class="col-4">
							<img src="./imgs/logo.png" alt="">
						</div>
						<div class="col-4 text-start">
							<p>شؤون الطلاب (بنين - بنات)</p>
							<p>العام الدراسي : <span>1444/8/2</span> </p>
						</div>
					</header>
					<div class="content">
						<h3 class="text-center mb-5">البيانات الدراسية</h3>
						<div class="three-col">
							<div class="box">
								<p class="fw-bold">القسم :</p>
								<p class="border-dashed">بنين</p>
							</div>
							<div class="box">
								<p class="fw-bold">المرحلة الدراسية :</p>
								<p class="border-dashed level-data">$educational_level</p>
							</div>
							<div class="box">
								<p class="fw-bold">نوع الدراسة :</p>
								<p class="border-dashed path-data">$educational_path</p>
							</div>
							<div class="box">
								<p class="fw-bold">الصف :</p>
								<p class="border-dashed class-data">$educational_class</p>
							</div>
							<div class="box">
								<p class="fw-bold">النقل :</p>
								<p class="border-dashed transport-data">$transport_type</p>
							</div>
						</div>
						<div class="ddd">
							<p>حرر هذاالعقد في : <span class="border-dashed"></span> <span>ـ بين كل من : </span> </p>
						</div>
						<div class="hhh">
							<p>شركة دار الشوامخ التعليمية وفرعها مدارس المجد الأهلية، ويشار إليه في هذه الاتفاقية بـ (الطرف الأول) </p>
							<div>
								<span class="fw-bold">و الطرف الثاني :</span>
								<span class="border-dashed parent-name">$parent_name</span>
							</div>
							<p class="mt-2 mb-2"><span class="fw-bold">التمهيد</span>: حيث أن الطرف الأول يمتلك مدارس أهلية لجميع المراحل بنين وبنات، ويرغب الطرف الثاني في تسجيل طالبـ / ـة بالمدارس، وعليه فقد اتفق الطرفان وهما بأهليتهما المعتبرة شرعا على المواد المرفقة ضمن اتفاقية التسجيل.</p>
						</div>
					</div>
					<div class="first mt-3 mb-3">
						<h3 class="bg-success text-white text-center p-2 mb-2"> بيانات الطالبـ/ـة </h3>
						<div class="three-col">

							<div class="box">
									<p class="fw-bold"> الاسم الطالب الكامل:</p>
									<p class="border-dashed fullname">$full_student_name</p>
							</div>

							<div class="box">
									<p class="fw-bold">رقم الهويه:</p>
									<p class="border-dashed civil-registry">$student_id_num</p>
							</div>


							<div class="box">
									<p class="fw-bold">الجنسية :</p>
									<p class="border-dashed nationality"></p>
							</div>

							<div class="box">
									<p class="fw-bold">ناريخ الميلاد :</p>
									<p class="border-dashed birth-day">$birthday</p>
							</div>

							<div class="box">
									<p class="fw-bold">تاريخ الميلاد الموافق هجري</p>
									<p class="border-dashed birth-day">$birthday_hijry</p>
							</div>

							<div class="box">
									<p class="fw-bold"> مدينة الميلاد :</p>
									<p class="border-dashed birth-day-city">$birthday_city</p>
							</div>

							<div class="box">
									<p class="fw-bold"> أخر شهادة دراسية :</p>
									<p class="border-dashed study-certificate">$study_certificate</p>
							</div>

							<div class="box">
									<p class="fw-bold"> حالة الدراسة:</p>
									<p class="border-dashed academic-status">$study_stutas</p>
							</div>

							<div class="box">
									<p class="fw-bold"> السابقة :</p>
									<p class="border-dashed pre-school"></p>
							</div>
							<div class="box">
									<p class="fw-bold"> الأمراض المزمنة التي يعاني منها  :</p>
									<p class="border-dashed illnesses">$illnesses</p>
							</div>
						</div>

					</div>
					<div class="second mt-3 mb-3">
						<h3 class="bg-success text-white text-center p-2">بيانات ولي الأمر</h3>
						<div class="three-col">

							<div class="box">
								<p class="fw-bold">الاسم  ولي الامر :</p>
								<p class="border-dashed parent-name"></p>
							</div>

							<div class="box">
								<p class="fw-bold">الجنسية ولي الأمر :</p>
								<p class="border-dashed parent-nationalty">$parent_name</p>
							</div>

							<div class="box">
								<p class="fw-bold">صلة القرابة :</p>
								<p class="border-dashed relative-relation">$reserve1_relation_parent</p>
							</div>

							<div class="box">
								<p class="fw-bold">نوع الهويه :</p>
								<p class="border-dashed id-type">$id_patent_type</p>
							</div>

							<div class="box">
								<p class="fw-bold">مصدرها :</p>
								<p class="border-dashed id-source">$id_source_parent</p>
							</div>

							<div class="box">
								<p class="fw-bold">رقمها :</p>
								<p class="border-dashed id-number">$parent_id_num</p>
							</div>

							<div class="box">
								<p class="fw-bold">ناريخ الانتهاء :</p>
								<p class="border-dashed id-finsh-date">$id_finish_date</p>
							</div>

							<div class="box">
								<p class="fw-bold">المهنة :</p>
								<p class="border-dashed job">$parent_job</p>
							</div>
							
							<div class="box">
								<p class="fw-bold">عنوان العمل :</p>
								<p class="border-dashed job-address">$parent_job_address</p>
							</div>

							<div class="box">
								<p class="fw-bold">هاتف العمل   :</p>
								<p class="border-dashed job-phone"></p>
							</div>
							

							<div class="box">
								<p class="fw-bold">البريد الالكتروني   :</p>
								<p class="border-dashed parent-emai">$parent_email</p>
							</div>

							<div class="box">
								<p class="fw-bold">عنوان السكن الحي   :</p>
								<p class="border-dashed neighborhood-address">$neighborhood_address</p>
							</div>

							<div class="box">
								<p class="fw-bold">الشارع الرئيسي   :</p>
								<p class="border-dashed main-street">$main_street</p>
							</div>

							<div class="box">
								<p class="fw-bold">الشارع الفرعي  :</p>
								<p class="border-dashed sub-street">$sub_street</p>
							</div>

							<div class="box">
								<p class="fw-bold">رقم المنزل   :</p>
								<p class="border-dashed house-number" >$house_num</p>
							</div>
							
							<div class="box">
								<p class="fw-bold">بجواز   :</p>
								<p class="border-dashed next-to">$next_to</p>
							</div>

							<div class="box">
								<p class="fw-bold">جوال المنزل   :</p>
								<p class="border-dashed home-phone"> $house_phone</p>
							</div>

						</div>
						<h3 class="mt-2 mb-2">  بيانات تعذر الاتصال</h3>
						<div class="three-col">

							<div class="box">
								<p class="fw-bold">الاسم الأول:</p>
								<p class="border-dashed reserve1-name">$reserve_name_1</p>
							</div>

							<div class="box">
								<p class="fw-bold">صلة القرابة:</p>
								<p class="border-dashed reserve1-relation">$reserve_relation_1</p>
							</div>

							<div class="box">
								<p class="fw-bold">الجوال :</p>
								<p class="border-dashed reserve1-phone"> $reserve_relation_phone_1</p>
							</div>

						</div>

						<div class="three-col">

							<div class="box">
								<p class="fw-bold">الاسم الثاني:</p>
								<p class="border-dashed reserve2-name"></p>
							</div>

							<div class="box">
								<p class="fw-bold">صلة القرابة:</p>
								<p class="border-dashed reserve2-relation">$reserve_relation_2</p>
							</div>

							<div class="box">
								<p class="fw-bold">الجوال :</p>
								<p class="border-dashed reserve2-phone">$reserve_relation_phone_2</p>
							</div>
						</div>


					</div> <!--  // end second  -->
				</div>  <!-- end contaienr  -->
			</section>
			<section class="registr-division d-none">
				<div class="container">
					<div class="third title mt-3 mb-3">
						<h3>خاص بقسم التسجيل:</h4>
					</div>
					<div class="tow-col">

						<div class="box">
							<p> رقم سند القبض</p>
							<p class="border-dashed"></p>
						</div>

						<div class="box">
							<p>تاريخه</p>
							<p class="border-dashed"></p>
						</div>

					</div>

					<div class="tow-col">
						<div class="box">
							<p> مدقق البيانات</p>
							<p class="border-dashed"></p>
						</div>
						<div class="box">
							<p>توقيعه</p>
							<p class="border-dashed"></p>
						</div>
					</div>			
				</div>
			</section>
			<section class="financial-department">
				<div class="container">
					<div class="fourd mt-3 mb-3">
						<h3 >******************    النظام المالي للطلاب والطالبات      ******************</h3>
					</div>
					<h4>المادة الاولى</h4>
					<p>إن هذا النظام يمثل الحقوق والواجبات المترتبة على الطرفين ( ولي الأمر والمدرسة ) ويمثل صفة تعاقد بينهما ويلتزمان بتنفيذه ومدته سنة دراسية واحدة تجدد بموافقة الطرفين ويعد بقاء ملف الطالب / الطالبة  موافقة من ولي الأمر على استمراره للسنة الجديدة حسب النظام والرسوم التي تقررها المدرسة</p>
					<h4>المادة الثانية:</h4>
					<p> نظام الرسوم الدراسية</p>
					<h5> 1- مقدار الرسوم الدراسية لعام دراسي كامل ( فصلين دراسيين):</h5>

					<div class="table-responsive mb-3">
						<table class="table align-middle table-hover">
							<thead>
								<tr class="table-secondary">
									<td>المجمع</td>
									<td>القسم</td>
									<td>روضة / تمهيدي</td>
									<td>الابتدائي تحفيظ-عام</td>
									<td>المتوسط تحفيظ-عام</td>
									<td>الثانوي</td>
								</tr>
							</thead>
							<tbody>
								<tr class="table-info">
									<td>مدارس المجد (فرع البديعة)</td>
									<td>بنين</td>
									<td>8500</td>
									<td>-</td>
									<td>-</td>
									<td>-</td>
								</tr>
								<tr class="table-light">
									<td>مدارس المجد (فرع العريجاء)</td>
									<td>بنات</td>
									<td>-</td>
									<td>11500</td>
									<td>13500</td>
									<td>16000</td>
								</tr>
								<tr class="table-info">
									<td>مدارس المجد (فرع نمار)</td>
									<td>بنين فقط</td>
									<td>-</td>
									<td>12000</td>
									<td>14000</td>
									<td>17000</td>
								</tr>
								<tr class="table-light">
									<td>دبلوما أمريكية</td>
									<td>بنين و بنات</td>
									<td>12800</td>
									<td>17000</td>
									<td>19000</td>
									<td>-</td>
								</tr>
							</tbody>
						</table>
					</div>

					<h5>2- نظام تخفيض الرسوم:</h5>

					<ol class="p-5">
						<li>
							<p>	يمنح ولي الأمر تخفيضاً إذا كان له أكثر من طالب علي النحو التالي (الابن الأكبر لا يمنح) (الابن الثاني5%) و(الابن الثالث فما فوق10%) ولا تشمل هذه التخفيضات مسار الدبلوما الأمريكية والتمهيدي والموهوبين.</p>
						</li>
						<li>
							<p>	تلغى نسبة الحسم من ولي الأمر آليا في حالة عدم التزامه بسداد الرسوم الدراسية قبل نهاية الفصل الدراسي أو التاريخ أو الفترة التي تحددها المدارس.</p>
						</li>
						<li>
							<p>في حالة منح الطلاب والطالبات خصومات عامة تلغى الخصومات الواردة في هذا العقد. </p>
						</li>
						<li>
							<p>	إذا التحق الطالب / الطالبة في المدارس بعد مضي فترة من الفصل الدراسي الأول أو الثاني يتوجب عليه دفع الرسوم الدراسية كاملة.</p>
						</li>
					</ol>

					<h5>3- آلية تسديد الرسوم الدراسية: </h5>
					<p>تدفع الرسوم الدراسية على قسطين القسط الأول عند التسجيل للمستجدين والاسبوع الأول للمستمرين للفصل الدراسي الأول والثاني. </p>

					<h4>المادة الثالثة : </h4>
					<p>: نظام الحركة والنقل لعام دراسي كامل ( فصلين دراسيين):</p>

					<div class="table-responsive mb-3">
						<table class="table align-middle table-hover">
							<thead>
								<tr class="table-secondary">
									<td>المسار</td>
									<td>الفصل الأول </td>
									<td>الفصل الثاني</td>
									<td>إجمالي العام</td>
								</tr>
							</thead>
							<tbody>
								<tr class="table-light">
									<td class="table-secondary">ذهاب وعودة (اتجاهين)</td>
									<td>2000</td>
									<td>2000</td>
									<td>4000</td>
								</tr>
								<tr class="table-info">
									<td class="table-secondary">ذهاب وعودة (اتجاه واحد)</td>
									<td>1750</td>
									<td>1750</td>
									<td>3500</td>
								</tr>
							</tbody>
						</table>
					</div>

					<ol class="p-5 pt-0">
						<li>	يتحمل ولي الأمر ضريبة القيمة المضافة للنقل</li>
						<li>	خط سير الحافلات تحدده إدارة النقل بالمدارس، وعلى ولي الأمر الالتزام به. </li>
						<li>يلتزم الطالب/الطالبة بانتظار الحافلة في الوقت الذي تحدده إدارة المدارس ولا تلتزم الحافلة بالعودة مرة أخري. </li>
						<li>	في حالة وجود ملحوظة على النقل يتم التواصل مع إدارة المدرسة فقط. </li>
					</ol>
				</div>
			</section>
			<section>
				<div class="container">
					<div class="wrapper">
						<h4>المادة الرابعة نظام الانسحاب (سحب الملف):</h4>
						<p>حيث يعتبر بقاء ملف الطالب / الطالبة في المدرسة الأسبوع الأول من بدء الدراسة موافقة على استمراره للسنة الجديدة ولو لم يقدم ولي الأمر طلباً رسمياً بذلك وحيث إن انسحاب الطالب / الطالبة بعد قبوله في المدرسة يحرم طالباً آخر من القبول بالمدارس فإن إدارة المدارس تأمل أن يتم سحب ملف الطالب قبل بدء اليوم الأول من الدراسة أما إذا تأخر ولي الأمر في نقل ابنه / ابنته من المدرسة فإنه يترتب عليه الآتي:</p>
						<div class="p-2 pt-0">
							<ol>
								<li>لحين بدء الأسبوع الثاني من الدراسة فإنه يتوجب عليه دفع 50 % من رسوم الفصل الدراسي.</li>
								<li>لحين بدء الأسبوع الثالث من الدراسة فإنه يتوجب عليه دفع رسوم الفصل الدراسي كاملة.</li>
								<li>يسري هذا النظام علي الرسوم الدراسية والنقل كما يسري على من يسجل في الفصل الدراسي الثاني. </li>
							</ol>
						</div>
					</div>
					<div class="wrapper">
						<h4>المادة الخامسة أحكام عامة:</h4>
						<div class="p-2 pt-0">
							<ol>
								<li>	تعتذر المدارس عن استقبال الأطفال بمرحلة رياض الأطفال مالم يتم سداد الرسوم الفصلية مع بداية كل فصل دراسي.</li>
								<li>	في حالة سحب الطالب من المدارس ترد الرسوم لولي الأمر على حسب مواعيد السحب المبينة في المادة الرابعة بشيك باسم ولي الأمر الذي سدد الرسوم.</li>
								<li>	يتحمل الطرف الثاني أي التزامات مالية إضافية تقر من الجهات الرسمية كضريبة القيمة المضافة وغيرها.  </li>
								<li>	أرقام هواتف ولي الأمر والبيانات المدونة في هذه الاستمارة هي التي يتم من خلالها التواصل معه ولا تتحمل المدارس أي مسؤولية إذا كانت البيانات غير صحيحة، وفي حال تغيير أي من الأرقام أو البيانات المدونة في هذه الاستمارة (خلف هذا العقد) يلتزم ولي الأمر بإشعار المدارس خطياً بالتغيير. </li>
								<li>	
									<p class="m-0">يلتزم ولي الأمر بسداد الرسوم الدراسية ورسوم النقل للمشترك في خدمة النقل قبل بدء كل فصل دراسي وفي حالة تأخر ولي الأمر عن سداد الرسوم الدراسية ورسوم النقل لمدة شهر من بداية الفصل الدراسي يحق للمدارس اتخاذ الإجراءات التالية بدون معارضة ولي الأمر أو الطالب/الطالبة مع حفظ حقوق المدارس المالية: </p>	
									<div class="p-4 pt-0">
										<ol class="list-style-square">
											<li>إيقاف الحافلة عن الطالب او الطالبة لحين سداد الرسوم </li>
											<li>	المنع من استلام أصول الشهادات والملف الرسمي وكذلك جميع إخوته وأخواته في المدارس لحين سداد كافة الرسوم. </li>
											<li>	المنع من سحب الملف أو نقله أو إدخال درجاته على برنامج نور إلا بعد إنهاء المستحقات المالية. </li>
											<li>	حجب التقارير الشهرية والفصلية. </li>
											<li>	يحق للمدارس اتخاذ الإجراء القانوني الذي يكفل حقها في الرسوم الدراسية في موعد أقصاه منتصف كل فصل دراسي مثال: سند لأمر، وغيرها من الإجراءات.</li>
										</ol>
									</div>
								</li>
								<li>	 يتعهد الطالب/الطالبة وولي الأمر بالمحافظة على ممتلكات المدرسة، وإذا حصل خلاف ذلك يلتزم الطالب / الطالبة وولي الأمر بدفع قيمة ما تم إتلافه أو استبداله على حسابه الخاص سواء بقصد أو بغير قصد منفرداً أو مع غيره من الطلاب وفي حالة تأخره يحق للمدارس إيقافه عن الدراسة ومطالبته من خلال الجهات المختصة بالوفاء بالالتزام. </li>
								<li>	يحق للمدارس استبعاد الطالب/الطالبة عن حافلات المدرسة في حال سوء سلوكه مع زملاءه أو الأخرين من أول مرة أو تسببه في التأخر في ركوب الحافلة مع احتفاظ المدارس بجميع حقوقها المالية وعدم المطالبة باسترداد رسومها أو المتبقي منها. </li>
								<li>	على الطالب / الطالبة التقيد بالزي المدرسي المعتمد والعباءة الساترة للطالبات وبالآداب الإسلامية والتمسك بها داخل المدرسة وحولها، والتقيد بالنظام والتعليمات الخاصة بالمدارس وجميع تعليمات الوزارة، أما بالنسبة للزي المدرسي يوفره ولي الأمر من الأسواق أو تقوم المدارس بتوفيره على حساب ولي الأمر. </li>
								<li>	في حال ارتكاب الطالب / الطالبة أياً من المخالفات الرسمية أو الإخلال بالنظام العام للمدارس فمن حق المدارس اتخاذ ما تراه مناسباً بما فيها استبعاد الطالب/الطالبة من المدرسة بدون اعتراض منه أو من ولي الأمر حسب ما تقتضيه مصلحة المدارس، مع احتفاظ المدارس بحقوقها المالية.</li>
								<li>	لا يجوز استمرار الطالب/الطالبة القديم أو دخوله إلى الصف في بداية السنة الدراسية الجديدة إلا بعد سداد الرسوم الدراسية المستحقة عليه من السنوات السابقة ويحق للمدارس إيقاف الطالب/الطالبة عن الدراسة مع بداية الفصل الدراسي الثاني إذا كان عليه رسوم دراسية متأخرة عن الفصل الدراسي الأول ويتحمل ولي الأمر كامل المسؤولية عن ذلك. </li>
								<li>	تعتمد إدارة المدارس لوائح الحسم كل نهاية عام للعام القادم ان وجدت وتعديل الرسوم الدراسية أو رسوم النقل ويكون بتسليم ولي الأمر أو الطالب خطاب أو إبلاغه بوسائل التواصل المعتمدة وذلك قبل بداية العام الدراسي الذي يشمله التعديل او الأسبوع الأول من بداية العام الجديد، وعدم سحب ملف الطالب نهاية العام يعنى موافقته على الرسوم الجديدة ولا يحق له الاعتراض على ذلك. </li>
								<li>	الطالب/ـة من خارج المملكة العربية السعودية أو من مدارس أجنبية داخل المملكة يشترط تقديم (أمر قبول من إدارة التعليم – معادلة الشهادات).</li>
								<li>	الطالب/ـة ومن هم أعمارهم أقل من سن القبول عليهم تقديم ما يفيد موافقة إدارة التعليم بقبولهم.</li>
								<li>	أسلوب التواصل المعتمد مع أولياء الأمور فيما يخص الرسوم الدراسية وغيرها يكون بخطاب يستلمه الطالب / الطالبة لإيصاله لولي أمره أو برسالة جوال نصية أو واتس آب على أرقام الجوالات المسجلة بطلب الالتحاق أو بالبريد الالكتروني وإذا حدث أي تعديل بالبيانات فيكون الاشعار على مسؤولية ولي الأمر بإبلاغ الإدارة المالية وإدارة القسم كلا على حدة. </li>
								<li>	يحق للمدارس تصوير الفعاليات والبرامج والأنشطة والقائمين عليها والمشاركين فيها، واستثمار المتفوقين والحاصلين على جوائز محلية وعالمية في الدعاية، ونشرها بوسائل التواصل الاجتماعي ووسائل الإعلام المختلفة وبدون الرجوع لولي الأمر. </li>
								<li>	أقر بأنني اطلعت على نظام الحضور والغياب وأن غياب 25% يحرمني من الدراسة. وأتحمل الرسوم الدراسية كاملة للفصل الدراسي.</li>
								<li>	في حال تبين لإدارة المدرسة وجود حالة من حالات التربية الخاصة أو فرط الحركة أو صعوبات التعلم فيحق لإدارة المدرسة الاعتذار من استمرار الطالب بالمدارس ضمن طلبة التعليم العام مع احتفاظ المدارس بحقوقها المالية. </li>
								<li>	في حالة انقطاع الطالب /الطالبة عن الدراسة أو بالاعتذار عن عام أو فصل دراسي يلزمه تقديم اعتذار رسمي للإدارة التنفيذية في المدارس ويعامل في ضوء ما ورد في المادة الرابعة.</li>
								<li>	المواد الإضافية وكراسات الأنشطة التي تقررها المدارس يلزم بها الطالب / الطالبة.</li>
								<li>	التقيد بالنظام الداخلي للمدارس والتعليمات الخاصة بها.</li>
								<li>	عند تأخر ولي الأمر عن سداد الرسوم الدراسية فيحق للمدارس المطالبة بها لدي المحاكم ويتحمل ولي الأمر أتعاب المحاماة والرسوم الإدارية الأخرى.</li>
								<li>	يتحمل ولي الأمر قيمة الكتب الدراسية، والزي المدرسي لمسار الدبلوما الأمريكية والتمهيدي (للبنين والبنات).</li>
								<li>	تستحق المدارس كامل الرسوم المحددة في العقد وكافة الرسوم الأخرى حتى وإن تم إيقاف أو إنهاء العام الدراسي أو جزء منه من جانب الجهات الرسمية بالدولة لأي سبب كان.</li>
								<li>	في حال حدوث ظروف غير متوقعة وخارجة عن الإرادة، سواء كانت ظروفا طارئة، أو قوة قاهرة مثل الحروب أو الأوبئة أو الزلازل أو غيرها في أي وقت من العام الدراسي، وتسببت في تأجيل أو إلغاء الدراسة أو تحويل الدراسة من حضورية إلى دراسة عن بعد، تكون الرسوم الدراسية ورسوم النقل مستحقة للمدارس كاملة، ولا يحق لولي الأمر مطالبة المدارس بإعفائه منها أو تخفيضها.</li>
							</ol>
						</div>
					</div>
				</div>
			</section>
			<section class=" pledge pb-3">
				<div class="container  border-top border-3 border-primary">
					<h3 >إقرار وتعهد</h3>
					<quotemeta>"أقر أن المعلومات الشخصية المدونة بعقد الاتفاق ودليل القبول والتسجيل صحيحة وعلى مسؤوليتي، وقد اطلعت على النظام المالي وأتعهد بالالتزام بمضمونه "</quotemeta>

					<div class="tow-col">

						<div class="box">
							<p>اسم ولي الأمر</p>
							<p class="border-dashed"></p>
						</div>

						<div class="box">
							<p>رقم السجل المدني</p>
							<p class="border-dashed"></p>
						</div>

						<div class="box">
							<p>التوقيع</p>
							<p class="border-dashed"></p>
						</div>
						
						<div class="box">
							<p>رقم الجوال</p>
							<p class="border-dashed"></p>
						</div>
					
				</div>
			</section>
		</main>   
	<style>
	* {
		margin: 0;
		padding: 0;
		box-sizing: border-box;
		text-align: right;
		direction: rtl;
		print-color-adjust: exact;
		-webkit-print-color-adjust: exact;
	}
	body {
		background-color: rgb(250, 249, 255);
		direction: rtl;
		padding: 15px 40px;
	}
	header {
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-bottom: 1.4px solid blue;
		padding-bottom: 5px;
		margin-bottom: 5px;
	}
	header img {
		width: 120px;
		margin: auto;
		display: inherit;
		background: white;
	}
	.tow-col {
		display: grid;
		grid-template-columns: repeat(2, auto);
		gap: 10px;
	}
	.three-col {
		display: grid;
		grid-template-columns: repeat(1, auto);
		grid-template-columns: repeat(3, auto);
		gap: 15px;
	}
	.three-col > * {
		display: inline-block;
	}
	article {
		padding-bottom: 15px;
		background: #000;
	}
	.border-dashed {
		border-bottom: dashed 2px #ddd;
		padding: 0px 22px;
	}

	section.registr-division ol li {
		display: flex;
		gap: 3px;
		align-items: center;
		margin-bottom: 5px;
	}
	section.registr-division ol li span:first-child {
		width: 20px;
		height: 20px;
		display: flex;
		border: 2px solid #ddd;
	}
	.list-style-square {
		list-style-type: square;
	}
	li {
		margin-bottom: 6px;
		font-size: 12px;
	}
	.box {
		display: flex;
		gap: 10px;
	}
	.box > :first-child {
		width: 100px;
	}
	section h3 {
		text-align: center;
		padding: 5px;
		background: #0DCAF0;
		margin-bottom: 5px;
		margin-top: 5px;
	}
	h4 {
		background: #198754;
		color: white;
		width: fit-content;
		padding: 5px;
	}
	h5 {
		text-align: center;
	}
	table {
		margin: auto;
		padding: 10px;
	}
	tr.table-info {
		background: #B8DAFF;
		
	}
	tr.table-light {
		background: #BEE5EB;
	}
	tr.table-secondary {
		background: #FFEEBA;
	}
	.box > :first-child {
		width: 100px;
	}
	section h3 {
		text-align: center;
		padding: 5px;
		background: #0DCAF0;
		margin-bottom: 5px;
		margin-top: 5px;
	}
	h4 {
		background: #198754;
		color: white;
		width: fit-content;
		padding: 5px;
	}
	h5 {
		text-align: center;
	}
	table {
		margin: auto;
		padding: 10px;
	}
	tr.table-info {
		background: #B8DAFF;
		
	}
	tr.table-light {
		background: #BEE5EB;
	}
	tr.table-secondary {
		background: #FFEEBA;
	}

	.forms-container-main {
		display: none !important;
	}
	.contract {
		display: block !important;
	}
	header.main-header {
		display: none;
	}
	header.header-contarct img {
		width: 70px;
	}
	.table>:not(caption)>*>* {
		padding: 4px;
		font-size: 8px;
	}
	title {
		display: none;
	}
	@page { size: auto;  margin: 0mm; }
	.container {
		width: 100%;
		padding: 15px;
		margin: auto;
	}
	</style>
contract_container;