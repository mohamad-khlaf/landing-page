<header class="main-header">
    <div class="container">
        <div class="contetn">

            <a href="https://almajd.edu.sa/" class="logo">
                <img src="./imgs/logo.png" alt="مدارس  المجد الاهلية">
            </a>
            <ul>
                <li><a href="http://almajd.edu.sa/">الصفحة الرئيسية</a></li>
                <li><a href="https://almajd.edu.sa/contact/">اتصل بنا</a></li>
            </ul>
        </div>
    </div>
</header>	