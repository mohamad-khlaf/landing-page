<?php

	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;


	require './LIB/mailer/Exception.php';
	require  "./LIB/mailer/PHPMailer.php";
	require  "./LIB/mailer/SMTP.php";

	$results = false;

	if ($_SERVER['REQUEST_METHOD'] == 'POST') {
		
		// ====================================================================================
		// Start Get Data From Inputs 
		include("./includes/mysqli.php");
		$educational_path 			= $_POST['educational_path'];
		$complex_name 				= $_POST['complex_name'];
		$educational_level 			= $_POST['educational_level'];
		$educational_class 			= $_POST['educational_class'];
		$transport_type 			= $_POST['transport_type'];
		$full_student_name 			= $_POST['full_student_name'];
		$student_id_num 			= $_POST['student_id_num'];
		// $nationalty 				= $_POST['nationalty'];
		$country 					= $_POST['country'];
		$birthday 					= $_POST['birthday'];
		$birthday_hijry 			= $_POST['birthday_hijry'];
		$birthday_city 				= $_POST['birthday_city'];
		$study_certificate 			= $_POST['study_certificate'];
		$study_stutas 				= $_POST['study_stutas'];
		$illnesses 					= $_POST['illnesses'];
		$parent_name 				= $_POST['parent_name'];
		$parent_nationalty 			= $_POST['parent_nationalty'];
		$reserve1_relation_parent 	= $_POST['reserve1_relation_parent'];
		$id_patent_type 			= $_POST['id_patent_type'];
		$id_source_parent 			= $_POST['id_source_parent'];
		$parent_id_num 				= $_POST['parent_id_num'];
		$id_finish_date 			= $_POST['id_finish_date'];
		$parent_job 				= $_POST['parent_job'];
		$parent_job_address 		= $_POST['parent_job_address'];
		$parent_email 				= $_POST['parent_email'];
		$neighborhood_address 		= $_POST['neighborhood_address'];
		$main_street 				= $_POST['main_street'];
		$sub_street 				= $_POST['sub_street'];
		$house_num 					= $_POST['house_num'];
		$next_to 					= $_POST['next_to'];
		$house_phone 				= $_POST['house_phone'];
		$reserve_name_1 			= $_POST['reserve_name_1'];
		$reserve_relation_1 		= $_POST['reserve_relation_1'];
		$reserve_relation_phone_1 	= $_POST['reserve_relation_phone_1'];
		$reserve_name_2 			= $_POST['reserve_name_2'];
		$reserve_relation_2 		= $_POST['reserve_relation_2'];
		$reserve_relation_phone_2 	= $_POST['reserve_relation_phone_2'];


		// غير موجودة في قاعدة البيانات
		$pre_school = $_POST['pre_school'];
		// ====================================================================================
		$sql = "INSERT INTO `regerster` (
			`educational_path`,
			`complex_name`,
			`educational_level`,
			`educational_class`,
			`transport_type`,
			`full_student_name`,
			`student_id_num`,
			`country`,
			`birthday`,
			`birthday_hijry`,
			`birthday_city`,
			`study_certificate`,
			`study_stutas`,
			`illnesses`,
			`parent_name`,
			`parent_nationalty`,
			`reserve1_relation_parent`,
			`id_patent_type`,
			`id_source_parent`,
			`parent_id_num`,
			`id_finish_date`,
			`parent_job`,
			`parent_job_address`,
			`parent_email`,
			`neighborhood_address`,
			`main_street`,
			`sub_street`,
			`house_num`,
			`next_to`,
			`house_phone`,
			`reserve_name_1`,
			`reserve_relation_1`,
			`reserve_relation_phone_1`,
			`reserve_name_2`,
			`reserve_relation_2`,
			`reserve_relation_phone_2`
			)
		  VALUES (
			'$educational_path',
			'$complex_name',
			'$educational_level',
			'$educational_class',
			'$transport_type',
			'$full_student_name',
			'$student_id_num',
			'$country',
			'$birthday',
			'$birthday_hijry',
			'$birthday_city',
			'$study_certificate',
			'$study_stutas',
			'$illnesses',
			'$parent_name',
			'$parent_nationalty',
			'$reserve1_relation_parent',
			'$id_patent_type',
			'$id_source_parent',
			'$parent_id_num',
			'$id_finish_date',
			'$parent_job',
			'$parent_job_address',
			'$parent_email',
			'$neighborhood_address',
			'$main_street',
			'$sub_street',
			'$house_num',
			'$next_to',
			'$house_phone',
			'$reserve_name_1',
			'$reserve_relation_1',
			'$reserve_relation_phone_1',
			'$reserve_name_2',
			'$reserve_relation_2',
			'$reserve_relation_phone_2'
			)";		
		$res = mysqli_query($connect, $sql);
		if (! $res) {
			// print last error message
			echo "Connect failed: %s\n", mysqli_error($connect);
			exit();
		}
		// ====================================================================================

		// Start PDF
		// require_once("./LIB/tcpdf/tcpdf.php");
		// $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

		// // set font
		// $pdf->SetFont('dejavusans', '', 10);    
		
		// // set image scale factor
		// $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);	 

		// // add a page*
		// $pdf->AddPage('L');        
		// $html = file_get_contents('layout/contracts.php');
		$html = <<<'hhh'
		
			<main class="contract " id="contract" dir="rtl">
				<section class="main-forms">
					<div class="container">
						<header class="">

							<div class="col-4">
								<span class="complex-data-title">$complex_name</span>
								<span>شركة دار الشوامخ التعليمية</span>
							</div>

							<div class="col-4 text-start " style="  direction: rtl; ">
								<span>شؤون الطلاب (بنين - بنات)</span>
								<span>العام الدراسي : <span>1444/8/2</span> </span>
							</div>

						</header>
						<div class="content">
							<h3 class="text-center mb-5">البيانات الدراسية</h3>
	

								<span class="box">
									<span class="border-dashed">بنين</span>
									<span class="fw-bold">القسم :</span>
								</span>

								<span class="box">
									<span class="border-dashed level-data">$educational_level</span>
									<span class="fw-bold">المرحلة الدراسية :</span>
								</span>

								<span class="box">
								<span class="border-dashed path-data">$educational_path</span>
									<span class="fw-bold">نوع الدراسة :</span>
								</span>

								<div> </div>

								<span class="box" dir="rtl">
									<span class="border-dashed class-data">$educational_class</span>
									<span class="fw-bold">الصف :</span>
								</span>

								<span class="box">
									<span class="border-dashed transport-data">$transport_type</span>
									<span class="fw-bold">النقل :</span>
								</span>
							</div>

							<div class="ddd">
								<p>حرر هذاالعقد في : <span class="border-dashed"></span> <span>ـ بين كل من : </span> </p>
							</div>

							<div class="hhh">
								<p>شركة دار الشوامخ التعليمية وفرعها مدارس المجد الأهلية، ويشار إليه في هذه الاتفاقية بـ (الطرف الأول) </p>
								<div>
									<span class="border-dashed parent-name">$parent_name</span>
									<span class="fw-bold">و الطرف الثاني :</span>
								</div>
								<p class="mt-2 mb-2"><span class="fw-bold">التمهيد</span>: حيث أن الطرف الأول يمتلك مدارس أهلية لجميع المراحل بنين وبنات، ويرغب الطرف الثاني في تسجيل طالبـ / ـة بالمدارس، وعليه فقد اتفق الطرفان وهما بأهليتهما المعتبرة شرعا على المواد المرفقة ضمن اتفاقية التسجيل.</p>
							</div>

						</div>
						<div class="first mt-3 mb-3">
							<h3 class="bg-success text-white text-center p-2 mb-2"> بيانات الطالبـ/ـة </h3>
							<div class="three-col">

								<div class="box">
										<span class="border-dashed fullname">$full_student_name</span>
										<span class="fw-bold"> الاسم الطالب الكامل:</span>
								</div>

								<div class="box">
									<span class="border-dashed civil-registry">$student_id_num</span>
									<span class="fw-bold">رقم الهويه:</span>
								</div>


								<div class="box">
									<span class="border-dashed nationality">السعوديه</span>
									<span class="fw-bold">الجنسية :</span>
								</div>

								<div class="box">
									<span class="border-dashed birth-day">$birthday</span>
									<span class="fw-bold">ناريخ الميلاد :</span>
								</div>

								<div class="box">
									<span class="border-dashed birth-day">$birthday_hijry</sp>
									<span class="fw-bold">تاريخ الميلاد الموافق هجري</sp>
								</div>

								<div class="box">
									<span class="border-dashed birth-day-city">$birthday_city</span>
									<span class="fw-bold"> مدينة الميلاد :</span>
								</div>

								<div class="box">
									<span class="border-dashed study-certificate">$study_certificate</s>
									<span class="fw-bold"> أخر شهادة دراسية :</s>
								</div>

								<div class="box">
									<span class="border-dashed academic-status">$study_stutas</span>
									<span class="fw-bold"> حالة الدراسة:</span>
								</div>

								<div class="box">
									<span class="border-dashed pre-school">$pre</span>
									<span class="fw-bold"> السابقة :</span>
								</div>
								<div class="box">
										<span class="fw-bold"> الأمراض المزمنة التي يعاني منها  :</span>
										<span class="border-dashed illnesses">$illnesses</span>
								</div>
							</div>

						</div>
						<div class="second mt-3 mb-3">
							<h3 class="bg-success text-white text-center p-2">بيانات ولي الأمر</h3>
							<div class="three-col">

								<div class="box">
									<span class="fw-bold">الاسم  ولي الامر :</span>
									<span class="border-dashed parent-name">$parent_name</span>
								</div>

								<div class="box">
									<span class="fw-bold">الجنسية ولي الأمر :</span>
									<span class="border-dashed parent-nationalty">$parent_name</span>
								</div>

								<div class="box">
									<span class="fw-bold">صلة القرابة :</span>
									<span class="border-dashed relative-relation">$reserve1_relation_parent</span>
								</div>

								<div class="box">
									<span class="fw-bold">نوع الهويه :</span>
									<span class="border-dashed id-type">$id_patent_type</span>
								</div>

								<div class="box">
									<span class="fw-bold">مصدرها :</span>
									<span class="border-dashed id-source">$id_source_parent</span>
								</div>

								<div class="box">
									<span class="fw-bold">رقمها :</span>
									<span class="border-dashed id-number">$parent_id_num</span>
								</div>

								<div class="box">
									<span class="fw-bold">ناريخ الانتهاء :</span>
									<span class="border-dashed id-finsh-date">$id_finish_date</span>
								</div>

								<div class="box">
									<span class="fw-bold">المهنة :</span>
									<span class="border-dashed job">$parent_job</span>
								</div>
								
								<div class="box">
									<span class="fw-bold">عنوان العمل :</span>
									<span class="border-dashed job-address">$parent_job_address</span>
								</div>

								<div class="box">
									<span class="fw-bold">هاتف العمل   :</span>
									<span class="border-dashed job-phone"></span>
								</div>
								

								<div class="box">
									<span class="fw-bold">البريد الالكتروني   :</span>
									<span class="border-dashed parent-emai">$parent_email</span>
								</div>

								<div class="box">
									<span class="fw-bold">عنوان السكن الحي   :</span>
									<span class="border-dashed neighborhood-address">$neighborhood_address</span>
								</div>

								<div class="box">
									<p class="fw-bold">الشارع الرئيسي   :</p>
									<p class="border-dashed main-street">$main_street</p>
								</div>

								<div class="box">
									<p class="fw-bold">الشارع الفرعي  :</p>
									<p class="border-dashed sub-street">$sub_street</p>
								</div>

								<div class="box">
									<p class="fw-bold">رقم المنزل   :</p>
									<p class="border-dashed house-number" >$house_num</p>
								</div>
								
								<div class="box">
									<p class="fw-bold">بجوار   :</p>
									<p class="border-dashed next-to">$next_to</p>
								</div>

								<div class="box">
									<p class="fw-bold">جوال المنزل   :</p>
									<p class="border-dashed home-phone"> $house_phone</p>
								</div>

							</div>
							<h3 class="mt-2 mb-2">  بيانات تعذر الاتصال</h3>
							<div class="three-col">

								<div class="box">
									<p class="fw-bold">الاسم الأول:</p>
									<p class="border-dashed reserve1-name">$reserve_name_1</p>
								</div>

								<div class="box">
									<p class="fw-bold">صلة القرابة:</p>
									<p class="border-dashed reserve1-relation">$reserve_relation_1</p>
								</div>

								<div class="box">
									<p class="fw-bold">الجوال :</p>
									<p class="border-dashed reserve1-phone"> $reserve_relation_phone_1</p>
								</div>

							</div>

							<div class="three-col">

								<div class="box">
									<p class="fw-bold">الاسم الثاني:</p>
									<p class="border-dashed reserve2-name"></p>
								</div>

								<div class="box">
									<p class="fw-bold">صلة القرابة:</p>
									<p class="border-dashed reserve2-relation">$reserve_relation_2</p>
								</div>

								<div class="box">
									<p class="fw-bold">الجوال :</p>
									<p class="border-dashed reserve2-phone">$reserve_relation_phone_2</p>
								</div>
							</div>


						</div> <!--  // end second  -->
					</div>  <!-- end contaienr  -->
				</section>
				<section class="registr-division d-none">
					<div class="container">
						<div class="third title mt-3 mb-3">
							<h3>خاص بقسم التسجيل:</h4>
						</div>
						<div class="tow-col">

							<div class="box">
								<p> رقم سند القبض</p>
								<p class="border-dashed"></p>
							</div>

							<div class="box">
								<p>تاريخه</p>
								<p class="border-dashed"></p>
							</div>

						</div>

						<div class="tow-col">
							<div class="box">
								<p> مدقق البيانات</p>
								<p class="border-dashed"></p>
							</div>
							<div class="box">
								<p>توقيعه</p>
								<p class="border-dashed"></p>
							</div>
						</div>			
					</div>
				</section>
				<section class="financial-department">
					<div class="container">
						<div class="fourd mt-3 mb-3">
							<h3 >******************    النظام المالي للطلاب والطالبات      ******************</h3>
						</div>
						<h4>المادة الاولى</h4>
						<p>إن هذا النظام يمثل الحقوق والواجبات المترتبة على الطرفين ( ولي الأمر والمدرسة ) ويمثل صفة تعاقد بينهما ويلتزمان بتنفيذه ومدته سنة دراسية واحدة تجدد بموافقة الطرفين ويعد بقاء ملف الطالب / الطالبة  موافقة من ولي الأمر على استمراره للسنة الجديدة حسب النظام والرسوم التي تقررها المدرسة</p>
						<h4>المادة الثانية:</h4>
						<p> نظام الرسوم الدراسية</p>
						<h5> 1- مقدار الرسوم الدراسية لعام دراسي كامل ( فصلين دراسيين):</h5>

						<div class="table-responsive mb-3">
							<table class="table align-middle table-hover">
								<thead>
									<tr class="table-secondary">
										<td>المجمع</td>
										<td>القسم</td>
										<td>روضة / تمهيدي</td>
										<td>الابتدائي تحفيظ-عام</td>
										<td>المتوسط تحفيظ-عام</td>
										<td>الثانوي</td>
									</tr>
								</thead>
								<tbody>
									<tr class="table-info">
										<td>مدارس المجد (فرع البديعة)</td>
										<td>بنين</td>
										<td>8500</td>
										<td>-</td>
										<td>-</td>
										<td>-</td>
									</tr>
									<tr class="table-light">
										<td>مدارس المجد (فرع العريجاء)</td>
										<td>بنات</td>
										<td>-</td>
										<td>11500</td>
										<td>13500</td>
										<td>16000</td>
									</tr>
									<tr class="table-info">
										<td>مدارس المجد (فرع نمار)</td>
										<td>بنين فقط</td>
										<td>-</td>
										<td>12000</td>
										<td>14000</td>
										<td>17000</td>
									</tr>
									<tr class="table-light">
										<td>دبلوما أمريكية</td>
										<td>بنين و بنات</td>
										<td>12800</td>
										<td>17000</td>
										<td>19000</td>
										<td>-</td>
									</tr>
								</tbody>
							</table>
						</div>

						<h5>2- نظام تخفيض الرسوم:</h5>

						<ol class="p-5">
							<li>
								<p>	يمنح ولي الأمر تخفيضاً إذا كان له أكثر من طالب علي النحو التالي (الابن الأكبر لا يمنح) (الابن الثاني5%) و(الابن الثالث فما فوق10%) ولا تشمل هذه التخفيضات مسار الدبلوما الأمريكية والتمهيدي والموهوبين.</p>
							</li>
							<li>
								<p>	تلغى نسبة الحسم من ولي الأمر آليا في حالة عدم التزامه بسداد الرسوم الدراسية قبل نهاية الفصل الدراسي أو التاريخ أو الفترة التي تحددها المدارس.</p>
							</li>
							<li>
								<p>في حالة منح الطلاب والطالبات خصومات عامة تلغى الخصومات الواردة في هذا العقد. </p>
							</li>
							<li>
								<p>	إذا التحق الطالب / الطالبة في المدارس بعد مضي فترة من الفصل الدراسي الأول أو الثاني يتوجب عليه دفع الرسوم الدراسية كاملة.</p>
							</li>
						</ol>

						<h5>3- آلية تسديد الرسوم الدراسية: </h5>
						<p>تدفع الرسوم الدراسية على قسطين القسط الأول عند التسجيل للمستجدين والاسبوع الأول للمستمرين للفصل الدراسي الأول والثاني. </p>

						<h4>المادة الثالثة : </h4>
						<p>: نظام الحركة والنقل لعام دراسي كامل ( فصلين دراسيين):</p>

						<div class="table-responsive mb-3">
							<table class="table align-middle table-hover">
								<thead>
									<tr class="table-secondary">
										<td>المسار</td>
										<td>الفصل الأول </td>
										<td>الفصل الثاني</td>
										<td>إجمالي العام</td>
									</tr>
								</thead>
								<tbody>
									<tr class="table-light">
										<td class="table-secondary">ذهاب وعودة (اتجاهين)</td>
										<td>2000</td>
										<td>2000</td>
										<td>4000</td>
									</tr>
									<tr class="table-info">
										<td class="table-secondary">ذهاب وعودة (اتجاه واحد)</td>
										<td>1750</td>
										<td>1750</td>
										<td>3500</td>
									</tr>
								</tbody>
							</table>
						</div>

						<ol class="p-5 pt-0">
							<li>	يتحمل ولي الأمر ضريبة القيمة المضافة للنقل</li>
							<li>	خط سير الحافلات تحدده إدارة النقل بالمدارس، وعلى ولي الأمر الالتزام به. </li>
							<li>يلتزم الطالب/الطالبة بانتظار الحافلة في الوقت الذي تحدده إدارة المدارس ولا تلتزم الحافلة بالعودة مرة أخري. </li>
							<li>	في حالة وجود ملحوظة على النقل يتم التواصل مع إدارة المدرسة فقط. </li>
						</ol>
					</div>
				</section>
				<section>
					<div class="container">
						<div class="wrapper">
							<h4>المادة الرابعة نظام الانسحاب (سحب الملف):</h4>
							<p>حيث يعتبر بقاء ملف الطالب / الطالبة في المدرسة الأسبوع الأول من بدء الدراسة موافقة على استمراره للسنة الجديدة ولو لم يقدم ولي الأمر طلباً رسمياً بذلك وحيث إن انسحاب الطالب / الطالبة بعد قبوله في المدرسة يحرم طالباً آخر من القبول بالمدارس فإن إدارة المدارس تأمل أن يتم سحب ملف الطالب قبل بدء اليوم الأول من الدراسة أما إذا تأخر ولي الأمر في نقل ابنه / ابنته من المدرسة فإنه يترتب عليه الآتي:</p>
							<div class="p-2 pt-0">
								<ol>
									<li>لحين بدء الأسبوع الثاني من الدراسة فإنه يتوجب عليه دفع 50 % من رسوم الفصل الدراسي.</li>
									<li>لحين بدء الأسبوع الثالث من الدراسة فإنه يتوجب عليه دفع رسوم الفصل الدراسي كاملة.</li>
									<li>يسري هذا النظام علي الرسوم الدراسية والنقل كما يسري على من يسجل في الفصل الدراسي الثاني. </li>
								</ol>
							</div>
						</div>
						<div class="wrapper">
							<h4>المادة الخامسة أحكام عامة:</h4>
							<div class="p-2 pt-0">
								<ol>
									<li>	تعتذر المدارس عن استقبال الأطفال بمرحلة رياض الأطفال مالم يتم سداد الرسوم الفصلية مع بداية كل فصل دراسي.</li>
									<li>	في حالة سحب الطالب من المدارس ترد الرسوم لولي الأمر على حسب مواعيد السحب المبينة في المادة الرابعة بشيك باسم ولي الأمر الذي سدد الرسوم.</li>
									<li>	يتحمل الطرف الثاني أي التزامات مالية إضافية تقر من الجهات الرسمية كضريبة القيمة المضافة وغيرها.  </li>
									<li>	أرقام هواتف ولي الأمر والبيانات المدونة في هذه الاستمارة هي التي يتم من خلالها التواصل معه ولا تتحمل المدارس أي مسؤولية إذا كانت البيانات غير صحيحة، وفي حال تغيير أي من الأرقام أو البيانات المدونة في هذه الاستمارة (خلف هذا العقد) يلتزم ولي الأمر بإشعار المدارس خطياً بالتغيير. </li>
									<li>	
										<p class="m-0">يلتزم ولي الأمر بسداد الرسوم الدراسية ورسوم النقل للمشترك في خدمة النقل قبل بدء كل فصل دراسي وفي حالة تأخر ولي الأمر عن سداد الرسوم الدراسية ورسوم النقل لمدة شهر من بداية الفصل الدراسي يحق للمدارس اتخاذ الإجراءات التالية بدون معارضة ولي الأمر أو الطالب/الطالبة مع حفظ حقوق المدارس المالية: </p>	
										<div class="p-4 pt-0">
											<ol class="list-style-square">
												<li>إيقاف الحافلة عن الطالب او الطالبة لحين سداد الرسوم </li>
												<li>	المنع من استلام أصول الشهادات والملف الرسمي وكذلك جميع إخوته وأخواته في المدارس لحين سداد كافة الرسوم. </li>
												<li>	المنع من سحب الملف أو نقله أو إدخال درجاته على برنامج نور إلا بعد إنهاء المستحقات المالية. </li>
												<li>	حجب التقارير الشهرية والفصلية. </li>
												<li>	يحق للمدارس اتخاذ الإجراء القانوني الذي يكفل حقها في الرسوم الدراسية في موعد أقصاه منتصف كل فصل دراسي مثال: سند لأمر، وغيرها من الإجراءات.</li>
											</ol>
										</div>
									</li>
									<li>	 يتعهد الطالب/الطالبة وولي الأمر بالمحافظة على ممتلكات المدرسة، وإذا حصل خلاف ذلك يلتزم الطالب / الطالبة وولي الأمر بدفع قيمة ما تم إتلافه أو استبداله على حسابه الخاص سواء بقصد أو بغير قصد منفرداً أو مع غيره من الطلاب وفي حالة تأخره يحق للمدارس إيقافه عن الدراسة ومطالبته من خلال الجهات المختصة بالوفاء بالالتزام. </li>
									<li>	يحق للمدارس استبعاد الطالب/الطالبة عن حافلات المدرسة في حال سوء سلوكه مع زملاءه أو الأخرين من أول مرة أو تسببه في التأخر في ركوب الحافلة مع احتفاظ المدارس بجميع حقوقها المالية وعدم المطالبة باسترداد رسومها أو المتبقي منها. </li>
									<li>	على الطالب / الطالبة التقيد بالزي المدرسي المعتمد والعباءة الساترة للطالبات وبالآداب الإسلامية والتمسك بها داخل المدرسة وحولها، والتقيد بالنظام والتعليمات الخاصة بالمدارس وجميع تعليمات الوزارة، أما بالنسبة للزي المدرسي يوفره ولي الأمر من الأسواق أو تقوم المدارس بتوفيره على حساب ولي الأمر. </li>
									<li>	في حال ارتكاب الطالب / الطالبة أياً من المخالفات الرسمية أو الإخلال بالنظام العام للمدارس فمن حق المدارس اتخاذ ما تراه مناسباً بما فيها استبعاد الطالب/الطالبة من المدرسة بدون اعتراض منه أو من ولي الأمر حسب ما تقتضيه مصلحة المدارس، مع احتفاظ المدارس بحقوقها المالية.</li>
									<li>	لا يجوز استمرار الطالب/الطالبة القديم أو دخوله إلى الصف في بداية السنة الدراسية الجديدة إلا بعد سداد الرسوم الدراسية المستحقة عليه من السنوات السابقة ويحق للمدارس إيقاف الطالب/الطالبة عن الدراسة مع بداية الفصل الدراسي الثاني إذا كان عليه رسوم دراسية متأخرة عن الفصل الدراسي الأول ويتحمل ولي الأمر كامل المسؤولية عن ذلك. </li>
									<li>	تعتمد إدارة المدارس لوائح الحسم كل نهاية عام للعام القادم ان وجدت وتعديل الرسوم الدراسية أو رسوم النقل ويكون بتسليم ولي الأمر أو الطالب خطاب أو إبلاغه بوسائل التواصل المعتمدة وذلك قبل بداية العام الدراسي الذي يشمله التعديل او الأسبوع الأول من بداية العام الجديد، وعدم سحب ملف الطالب نهاية العام يعنى موافقته على الرسوم الجديدة ولا يحق له الاعتراض على ذلك. </li>
									<li>	الطالب/ـة من خارج المملكة العربية السعودية أو من مدارس أجنبية داخل المملكة يشترط تقديم (أمر قبول من إدارة التعليم – معادلة الشهادات).</li>
									<li>	الطالب/ـة ومن هم أعمارهم أقل من سن القبول عليهم تقديم ما يفيد موافقة إدارة التعليم بقبولهم.</li>
									<li>	أسلوب التواصل المعتمد مع أولياء الأمور فيما يخص الرسوم الدراسية وغيرها يكون بخطاب يستلمه الطالب / الطالبة لإيصاله لولي أمره أو برسالة جوال نصية أو واتس آب على أرقام الجوالات المسجلة بطلب الالتحاق أو بالبريد الالكتروني وإذا حدث أي تعديل بالبيانات فيكون الاشعار على مسؤولية ولي الأمر بإبلاغ الإدارة المالية وإدارة القسم كلا على حدة. </li>
									<li>	يحق للمدارس تصوير الفعاليات والبرامج والأنشطة والقائمين عليها والمشاركين فيها، واستثمار المتفوقين والحاصلين على جوائز محلية وعالمية في الدعاية، ونشرها بوسائل التواصل الاجتماعي ووسائل الإعلام المختلفة وبدون الرجوع لولي الأمر. </li>
									<li>	أقر بأنني اطلعت على نظام الحضور والغياب وأن غياب 25% يحرمني من الدراسة. وأتحمل الرسوم الدراسية كاملة للفصل الدراسي.</li>
									<li>	في حال تبين لإدارة المدرسة وجود حالة من حالات التربية الخاصة أو فرط الحركة أو صعوبات التعلم فيحق لإدارة المدرسة الاعتذار من استمرار الطالب بالمدارس ضمن طلبة التعليم العام مع احتفاظ المدارس بحقوقها المالية. </li>
									<li>	في حالة انقطاع الطالب /الطالبة عن الدراسة أو بالاعتذار عن عام أو فصل دراسي يلزمه تقديم اعتذار رسمي للإدارة التنفيذية في المدارس ويعامل في ضوء ما ورد في المادة الرابعة.</li>
									<li>	المواد الإضافية وكراسات الأنشطة التي تقررها المدارس يلزم بها الطالب / الطالبة.</li>
									<li>	التقيد بالنظام الداخلي للمدارس والتعليمات الخاصة بها.</li>
									<li>	عند تأخر ولي الأمر عن سداد الرسوم الدراسية فيحق للمدارس المطالبة بها لدي المحاكم ويتحمل ولي الأمر أتعاب المحاماة والرسوم الإدارية الأخرى.</li>
									<li>	يتحمل ولي الأمر قيمة الكتب الدراسية، والزي المدرسي لمسار الدبلوما الأمريكية والتمهيدي (للبنين والبنات).</li>
									<li>	تستحق المدارس كامل الرسوم المحددة في العقد وكافة الرسوم الأخرى حتى وإن تم إيقاف أو إنهاء العام الدراسي أو جزء منه من جانب الجهات الرسمية بالدولة لأي سبب كان.</li>
									<li>	في حال حدوث ظروف غير متوقعة وخارجة عن الإرادة، سواء كانت ظروفا طارئة، أو قوة قاهرة مثل الحروب أو الأوبئة أو الزلازل أو غيرها في أي وقت من العام الدراسي، وتسببت في تأجيل أو إلغاء الدراسة أو تحويل الدراسة من حضورية إلى دراسة عن بعد، تكون الرسوم الدراسية ورسوم النقل مستحقة للمدارس كاملة، ولا يحق لولي الأمر مطالبة المدارس بإعفائه منها أو تخفيضها.</li>
								</ol>
							</div>
						</div>
					</div>
				</section>
				<section class=" pledge pb-3">
					<div class="container  border-top border-3 border-primary">
						<h3 >إقرار وتعهد</h3>
						<quotemeta>"أقر أن المعلومات الشخصية المدونة بعقد الاتفاق ودليل القبول والتسجيل صحيحة وعلى مسؤوليتي، وقد اطلعت على النظام المالي وأتعهد بالالتزام بمضمونه "</quotemeta>

						<div class="tow-col">

							<div class="box">
								<p>اسم ولي الأمر</p>
								<p class="border-dashed"></p>
							</div>

							<div class="box">
								<p>رقم السجل المدني</p>
								<p class="border-dashed"></p>
							</div>

							<div class="box">
								<p>التوقيع</p>
								<p class="border-dashed"></p>
							</div>
							
							<div class="box">
								<p>رقم الجوال</p>
								<p class="border-dashed"></p>
							</div>
						
					</div>
				</section>
			</main>   
			<style>
			* {
				margin: 0;
				padding: 0;
				box-sizing: border-box;
				text-align: right;
				direction: rtl;
				print-color-adjust: exact;
				-webkit-print-color-adjust: exact;
			}
			body {
				background-color: rgb(250, 249, 255);
				direction: rtl;
				padding: 15px 40px;
			}
			header {
				display: flex;
				justify-content: space-between;
				align-items: center;
				border-bottom: 1.4px solid blue;
				padding-bottom: 5px;
				margin-bottom: 5px;
			}
			header img {
				width: 120px;
				margin: auto;
				display: inherit;
				background: white;
			}
			.tow-col {
				display: grid;
				grid-template-columns: repeat(2, auto);
				gap: 10px;
			}
			.three-col {
				display: grid;
				grid-template-columns: repeat(1, auto);
				grid-template-columns: repeat(3, auto);
				gap: 15px;
			}
			.three-col > * {
				display: inline-block;
			}
			article {
				padding-bottom: 15px;
				background: #000;
			}
			.border-dashed {
				border-bottom: dashed 2px #ddd;
				padding: 0px 22px;
			}

			section.registr-division ol li {
				display: flex;
				gap: 3px;
				align-items: center;
				margin-bottom: 5px;
			}
			section.registr-division ol li span:first-child {
				width: 20px;
				height: 20px;
				display: flex;
				border: 2px solid #ddd;
			}
			.list-style-square {
				list-style-type: square;
			}
			li {
				margin-bottom: 6px;
				font-size: 12px;
			}
			.box {
				display: flex;
				gap: 10px;
			}
			.box > :first-child {
				width: 100px;
			}
			section h3 {
				text-align: center;
				padding: 5px;
				background: #0DCAF0;
				margin-bottom: 5px;
				margin-top: 5px;
			}
			h4 {
				background: #198754;
				color: white;
				width: fit-content;
				padding: 5px;
			}
			h5 {
				text-align: center;
			}
			table {
				margin: auto;
				padding: 10px;
			}
			tr.table-info {
				background: #B8DAFF;
				
			}
			tr.table-light {
				background: #BEE5EB;
			}
			tr.table-secondary {
				background: #FFEEBA;
			}
			.box > :first-child {
				width: 100px;
			}
			section h3 {
				text-align: center;
				padding: 5px;
				background: #0DCAF0;
				margin-bottom: 5px;
				margin-top: 5px;
			}
			h4 {
				background: #198754;
				color: white;
				width: fit-content;
				padding: 5px;
			}
			h5 {
				text-align: center;
			}
			table {
				margin: auto;
				padding: 10px;
			}
			tr.table-info {
				background: #B8DAFF;
				
			}
			tr.table-light {
				background: #BEE5EB;
			}
			tr.table-secondary {
				background: #FFEEBA;
			}

			.forms-container-main {
				display: none !important;
			}
			.contract {
				display: block !important;
			}
			header.main-header {
				display: none;
			}
			header.header-contarct img {
				width: 70px;
			}
			.table>:not(caption)>*>* {
				padding: 4px;
				font-size: 8px;
			}
			title {
				display: none;
			}
			@page { size: auto;  margin: 0mm; }
			.container {
				width: 100%;
				padding: 15px;
				margin: auto;
			}
			</style>

		hhh;

		// // create new PDF document
		// $pdf->SetTitle('عقد');

		// $pdf->writeHTML($html, true, false, true, false, '');

		// //Close and output PDF document
		// ob_get_clean();
		// $name_file = 'عقد الطالب.pdf';
		// $pdf_file = $pdf->Output('ddd.pdf', 'S');

		// ====================================================================================
		// Start Sending EMAIL البيانات المرسلة للبريد الإلكتروني 
        // file_put_contents($name_file, $pdf_file);
		// Start Sending Data If NO Errors 
		$mail = new PHPMailer();
		$mail->isSMTP();   
		$mail->Host       	= 'smtp.gmail.com';
		$mail->SMTPAuth   	= true;
		$mail->CharSet   	= "UTF-8";
		$mail->SMTPSecure 	= 'tls';
		$mail->Port       	= '587';
		$mail->Username   	= 'mohamadalkhlaf1@gmail.com';
		$mail->Password   	= 'mbjtisiragfjgzao'; 
		$mail->Subject 		= ' التسجيل الالكتروني مدارس المجد';
		$mail->Body    		= ' تم أرسال هذه الرسالة للتأكد من تمام عملية التسجيل الالكتروني';
		$mail->setFrom('mohamadalkhlaf1@gmail.com', 'مدارس المجد الأهلية- info@almajd.edu.sa');
		$mail->addAddress($parent_email, 'مدارس المجد'); 
		// add pdf attachment to php mailer

		// $mail->addAttachment($name_file);


		// successful send one img 

		if (isset($_FILES['img_1'])) {
			$mail->addAttachment( $_FILES['img_1']['tmp_name'], $_FILES['img_1']['name'] );
		} else {
			echo "false upload img imgs_id";
		}

		if ($mail->send()) {
			$results = "لقد تم أرسال رسالة بريد  الخاصة بك";
		} else {
			$results = "فاشل ارسال الرسالة " . $mail->ErrorInfo;
		}
		$mail->smtpClose();
		// unlink($name_file);

		// ====================================================================================
		// Start Send Massage بيانات الرسالة النصية 
		// include("LIB/OTSMS.php");
		
		include("LIB/sms/OTSMS.php");



		$UserName		= "11194";
		$UserPassword	= "62292301";
		$Originator		= "Almajd";
    	$Message		= "تم تسجيل البيانات بنجاح  ".	$full_student_name ."في مدارس المجد الأهلية  ";

		$SendingResult = SendSms($UserName,$UserPassword,$house_phone,$Originator,$Message);
		
		if($SendingResult=="1"){
			echo "sss تم إرسال الرسالة بنجاح";
		}elseif($SendingResult=="1010"){
			echo "معلومات ناقصة.. اسم المستخدم أو كلمة المرور أو في محتوى الرسالة أو الرقم";
		}elseif($SendingResult=="1020"){
			echo "بيانات الدخول خاطئة";
		}elseif($SendingResult=="1030"){
			echo "نفس الرسالة مع نفس الاتجاه توجد في الملحق، انتظر عشر ثواني قبل إعادة إرسالها";
		}elseif($SendingResult=="1040"){
			echo "حروف غير معترف بها ";
		}elseif($SendingResult=="1050"){
			echo "الرسالة فارغة، السبب:الانتقاء قد سبب حذف محتوى الرسالة";
		}elseif($SendingResult=="1060"){
			echo "اعتماد غير كافي لعميلة الإرسال";
		}elseif($SendingResult=="1070"){
			echo "رصيدك 0 ، غير كافي لعملية الإرسال";
		}elseif($SendingResult=="1080"){
			echo "رسالة غير مرسلة ، خطأ في عملية إرسال رسالة";
		}elseif($SendingResult=="1090"){
			echo "تكرير عملية الانتقاء أنتج الرسالة";
		}elseif($SendingResult=="1100"){
			echo "عذرا ، لم يتم إرسال الرسالة. حاول في وقت لاحق";
		}elseif($SendingResult=="1110"){
			echo "عذرا، هناك اسم مرسل خاطئ ثم استعماله، حاول من جديد تصحيح الاسم";
		}elseif($SendingResult=="1120"){
			echo "عذرا ، هذا البلد الذي تحاول الإرسال له لا تشمله شبكتنا";
		}elseif($SendingResult=="1130"){
			echo "عذرا، راجع المشرف على شبكاتنا باعتبار الشبكة المحددة في حسابكم";
		}elseif($SendingResult=="1140"){
			echo "عذرا ، تجاوزت الحد الأقصى لأجزاء الرسائل. حاول إرسال عدد أقل من الأجزاء";
		}elseif($SendingResult=="1150"){
			echo "هذه الرسالة مكررة بنفس رقم الجوال واسم المرسل ونص الرسالة";
		}elseif($SendingResult=="1160"){
			echo "هناك مشكلة في مدخلات تاريخ وتوقيت الإرسال اللاحق";
		}else{
			echo $SendingResult;
		}	
	
	}

?>

<!DOCTYPE html>
<html lang="en" dir="rtl">
	<head>
		<?php include('./layout/head.php'); ?>
		<link rel="stylesheet" href="./assets/css/all.min.css">
		<link rel="stylesheet" href="./assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="./assets/css/registration.css">
		<title>نموذج فتح حساب  </title>
	</head>
	<body>

		<main class="forms-container-main">
			<div class="container">
				<h1 class="text-center"> نموذج تسجيل طالب</h1>
				
				<?php if ($results != false) {
					echo <<<"alter"
						<div class='alert-send alert alert-primary alert-dismissible position-fixed show' role='alert'>
							<strong>شكرا لك </strong>
							$results 
							<button type='button' class='close' data-dismiss='alert' aria-label='Close'>
								<span aria-hidden='true'>&times;</span>
							</button>
						</div>
					alter;
				} ?>

				<form 	class="text-right" 

						method="POST" 
						action="<?php echo $_SERVER['PHP_SELF'] ?>" 
						enctype="multipart/form-data"
				>
				<div class="form-registration">

					<article class="school-data">

						<h2 class="sub-title">البيانات الدراسية</h2>
						<div class="three-col home-select">


						
							<div class="path-container input-group mb-3" >
								<label class=" bg-label" for="path">اختار المسار</label>
								<select data-type="path" name="educational_path"  class="form-select" id="path">
									<!-- <option   value="" selected>اختار</option> -->
									<option   value="path_1" selected>مسار التعليم العام </option>
									<option   value="path_2">مسار تحفيظ القرآن الكريم			</option>
									<option   value="path_3">مسار الدبلوما الأمريكية	</option>
									<option   value="path_4">مسار الطفولة المبكرة   </option>
								</select>
								<i class="fa-solid fa-star required-inputs"></i>	
								<small id="emailHelp" class="form-text text-muted">
									<?php
										// if(isset($phoneErrors)) :
										// 	if ($phoneErrors !== '' ) : echo $phoneErrors;
										// 	else : echo 'valid phone number';
										// 	endif;		
										// else : echo "We'll never share your email with anyone else.";
										// endif; 
									?>
								</small>														
							</div>
								
							<div class="complex-container input-group mb-3 complex" id="complex">
								<label class=" bg-label" for="complex">اختار المجمع</label>
								
								<select data-type="complex" name="complex_name" class="complex-class-select  form-select " >
									<!-- <option  value=""   selected>اختار</option> -->
									<option  value="complex_1" selected   >ابتدائية البديعة بنين</option>
									<option  value="complex_2"  		  >مجمع العريجاء بنين</option>
									<option  value="complex_3"   		  >مجمع نمار بنين</option>
									<option  value="complex_4"       	  >مجمع البنات الجديد</option>
								</select>
								<i class="fa-solid fa-star required-inputs"></i>							
							</div>

							<div class="input-group level-container mb-3">
								<label class=" bg-label" for="level">المرحلة الدراسية</label>
								<select data-type="level" name="educational_level"  class="school-level  form-select" id="level">
									<!-- <option value="" selected>أختر  </option> -->
									<option value="level_1" selected     >رياض الأطفال </option>
									<option value="level_2" 		     >المرحلة الابتدائية</option>
									<option value="level_3" 	    	  >المرحلة المتوسطة</option>
									<option value="level_4" 		  >المرحلة الثانوية</option>
								</select>
								<i class="fa-solid fa-star required-inputs"></i>							
							</div>

							<div class="input-group mb-3">
								<label class=" bg-label" for="class">الصف الدراسي</label>
								<select data-type="classes" name="educational_class" require  class=" form-select" id="class">
									<!-- <option value="" selected>أختر</option> -->
									<option value="class_1" selected >الأول</option>
									<option value="class_2" > الثاني </option>
									<option value="class_3" > الثالث </option>
									<option value="class_4" > الرابع </option>
									<option value="class_5" > الخامس </option>
									<option value="class_6" > السادس </option>
								</select>
								<i class="fa-solid fa-star required-inputs"></i>							
							</div>
												
							<div class="input-group level-container mb-3">						
								<label class=" bg-label" for="class">النقل</label>
								<select  name="transport_type" require data-class="transport-data" class="form-select" id="class">
									<option value="" selected>أختر</option>
									<option value="غير مشترك" >غير مشترك</option>
									<option value="مشترك" 		  >مشترك</option>
								</select>

						</div>

						



					</article>
				</div>
				<div class="form-registration">
					<article>
						<h2 class="sub-title">بيانات الطالبـ/ـة</h2>
						<div class="three-col">
							
							<div class="input-group mb-3 gap-1 ">
								<label class="bg-label"> اسم الطالب كامل</label>
								<input require name="full_student_name" require  type="text"  class="form-control"  id="companyName"   requited data-class="fullname" value="<?php  if(isset($fullname)) echo $fullname; ?>">
								<i class="fa-solid fa-star required-inputs"></i>							
							</div>
												
							<div class="input-group mb-3 gap-1">
								<label class="bg-label">رقم هويه الطالب</label>
								<input  require name="student_id_num"  type="text"  class="form-control"  id="ownerName"   data-class="civil-registry" value="<?php if(isset($owner_name)) echo $owner_name;?>" >
								<i class="fa-solid fa-star required-inputs"></i>							
							</div>

							<div class="input-group mb-3 gap-1">
								<label class="bg-label">الجنسية</label>
								<select require name="country" data-class="nationality" class="form-select">
									<option value="السعودية">السعودية</option>
									<option value="الكويت">الكويت</option>
									<option value="الامارات">الامارات</option>
                                    <option value="البحرين">البحرين</option>
                                    <option value="مصر">مصر</option>
                                    <option value="السودان">السودان</option>
                                    <option value="سوريا">سوريا</option>
									<option value="اليمن">اليمن</option>
									<option value="العراق">العراق</option>
									<option value="تونس">تونس</option>
                                    <option value="الأردن">الأردن</option>
									<option value="الجزائر">الجزائر</option>
								</select>							
								<i class="fa-solid fa-star required-inputs"></i>							
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for=""> تاريخ الميلاد</label>
								<input name="birthday" require type="text" id="ContentPlaceHolder1_PageData_ucZawga_PersonDataControl1_ucBirthDate_pickCalHj" class="pickCalHj form-control" readonly="readonly" placeholder="هجري" />
								<i class="fa-solid fa-star required-inputs"></i>							
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for=""> تاريخ الميلاد</label>
								<!-- <input    type="date"  class="form-control" placeholder="هجري"     data-class="birth-day" value="<?php  ?>"> -->
								<input name="birthday_hijry" require type="text" id="ContentPlaceHolder1_PageData_ucZawga_PersonDataControl1_ucBirthDate_pickCalGer" class="pickCalGer form-control" readonly="readonly" placeholder="ميلادي" />							
								<i class="fa-solid fa-star required-inputs"></i>							
							</div>
					
							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">مكان الولادة</label>
								<input name="birthday_city" require data-class="birth-day-city"   type="text"  class="form-control"    >
								<i class="fa-solid fa-star required-inputs"></i>							
							</div>
					
						
							<div class="input-group mb-3 gap-1">
								<label class="bg-label" for="">آخر شهادة دراسية</label>
								<select require name="study_certificate" data-class="studycertificate" class="form-select">
									<option value="" selected>اختار</option>
									<option value="تمهيدي">تمهيدي</option>
									<option value="أول ابتدائي">أول ابتدائي</option>
									<option value="ثاني ابتدائي">ثاني ابتدائي</option>
                                    <option value="ثالث ابتدائي">ثالث ابتدائي</option>
                                    <option value="رابع ابتدائي">رابع ابتدائي</option>
                                    <option value="خامس ابتدائي">خامس ابتدائي</option>
                                    <option value="سادس ابتدائي">سادس ابتدائي</option>
									<option value="أول متوسط">أول متوسط</option>
									<option value="ثاني متوسط">ثاني متوسط</option>
									<option value="ثالث متوسط">ثالث متوسط</option>
                                    <option value="أول ثانوي">أول ثانوي</option>
									<option value="ثاني ثانوي">ثاني ثانوي</option>
									<option value="لايوجد">لايوجد</option>							
									</select>							
								<i class="fa-solid fa-star required-inputs"></i>							
							</div>

							
					
							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">حالة الدراسة</label>
								<select name="study_stutas" require class="form-select" data-class="academic-status" >
									<option value="" selected>اختار</option>
									<option value="مستجد" selected>مستجد</option>
									<option value="منقول من مدرسة أخرى" 		  >منقول من مدرسة أخرى</option>
								</select>
								<i class="fa-solid fa-star required-inputs"></i>							
							</div>
					
							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">المدرسة السابقة:</label>
								<input name="pre_school" data-class="pre-school"   type="text"  class="form-control"    >
							</div>
					
							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">الأمراض المزمنة  :</label>
								<input  name="illnesses" data-class="illnesses" type="text"  class="form-control"    >
							</div>
							</div>	
					</article>
                </div>
				<div class="form-registration">
					<article>
						<h2 class="sub-title"> بيانات ولي الأمر</h2>
						<div class="three-col">
					
							<div class="input-group mb-3 gap-1">
									<label class=" bg-label" for="">اسم ولي الأمر</label>
									<input  name="parent_name" require data-class="parent-name" type="text"  class="form-control"    >
									<i class="fa-solid fa-star required-inputs"></i>							
							</div>
                            
                            <div class="input-group mb-3 gap-1">
								<label class="bg-label">الجنسية</label>
								<select require name="parent_nationalty" data-class="parent-nationalty" class="form-select">
									<option value="السعودية">السعودية</option>
									<option value="الكويت">الكويت</option>
									<option value="الامارات">الامارات</option>
                                    <option value="البحرين">البحرين</option>
                                    <option value="مصر">مصر</option>
                                    <option value="السودان">السودان</option>
                                    <option value="سوريا">سوريا</option>
									<option value="اليمن">اليمن</option>
									<option value="العراق">العراق</option>
									<option value="تونس">تونس</option>
                                    <option value="الأردن">الأردن</option>
									<option value="الجزائر">الجزائر</option>
								</select>							
								<i class="fa-solid fa-star required-inputs"></i>							
							</div>
						
							
							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">صلة القرابة</label>
								<select name="reserve1_relation_parent" require data-class="reserve1-relation form-select" class="form-select" data-class="academic-status" >
									<option value="الوالد" selected>الوالد</option>
									<option value="الوالدة">الوالدة</option>
									<option value="أخ">أخ			</option>
									<option value="أخت">أخت			</option>
									<option value="عمـ/ـة" >عمـ/ـة	</option>
									<option value="خالـ/ـة" >خالـ/ـة</option>
									<option value="جد/ة"> جد/ة		</option>
									<option value="أخرى"> أخرى		</option>
								</select>
								<i class="fa-solid fa-star required-inputs"></i>	
							</div>
					
							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">نوع الهوية</label>
								<select name="id_patent_type" require data-class="id-type form-select" class="form-select" data-class="academic-status" >
									<option value="" selected>اختار</option>
									<option value="هويه مواطن" selected>هويه مواطن</option>
									<option value="هويه مقيم ">هويه مقيم </option>
								</select>
								<i class="fa-solid fa-star required-inputs"></i>	
							</div>
					
							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">مصدر الهوية</label>
								<input name="id_source_parent" require data-class="id-source"   type="text"  class="form-control"    >
								<i class="fa-solid fa-star required-inputs"></i>	
							</div>
					
							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">رقم الهوية</label>
								<input name="parent_id_num" require data-class="id-number"   type="number"  class="form-control"    >
								<i class="fa-solid fa-star required-inputs"></i>	
							</div>

						
							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">مهنة ولي الأمر</label>
								<input name="parent_job" require data-class="job"   type="text"  class="form-control"    >
								<i class="fa-solid fa-star required-inputs"></i>	
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">عنوان العمل</label>
								<input name="parent_job_address" require data-class="job-address"   type="text"  class="form-control"    >
								<i class="fa-solid fa-star required-inputs"></i>	
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">البريد الالكتروني</label>
								<input name="parent_email" require data-class="parent-emai" name="email"  type="text"  class="form-control"    >
								<i class="fa-solid fa-star required-inputs"></i>	
							</div>


						</div>
					</article>
                </div>	
				<div class="form-registration">
					<article>
						<h2 class="sub-title">بيانات العنوان والاتصال</h2>
						<div class="three-col">

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">جوال  ولي الأمر</label>
								<input name="house_phone" data-class="home-phone"  type="number" placeholder="********05"    class="form-control"    >
							</div>
							
							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">عنوان السكن (الحي)</label>
								<input name="neighborhood_address" require data-class="neighborhood-address"   type="text"  class="form-control"    >
								<i class="fa-solid fa-star required-inputs"></i>	
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">الشارع الرئيسي</label>
								<input name="main_street" require data-class="main-street"   type="text"  class="form-control"    >
								<i class="fa-solid fa-star required-inputs"></i>	
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">الشارع الفرعي</label>
								<input name="sub_street" data-class="sub-street"   type="text"  class="form-control"    >
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">رقم المنزل</label>
								<input name="house_num" require data-class="house-number"   type="text"  class="form-control"    >
								<i class="fa-solid fa-star required-inputs"></i>	
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">بجوار </label>
								<input name="next_to" data-class="next-to"   type="text"  class="form-control"    >
							</div>
							</div>
							  </article>
							
                        	<article>
	                            <p>  وفي حالة تعذر الاتصال بك عند الضرورة نرجو ذكر اسم وعنوان اثنين يمكن الاتصال بهما</p>
                            </article>
                            <article>
                            
                            	<div class="three-col">
                            	<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for=""> الاسم الأول</label>
								<input name="reserve_name_1" require data-class="reserve1-name"   type="text"  class="form-control"    >
								<i class="fa-solid fa-star required-inputs"></i>
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">صلة القرابة</label>
								<select name="reserve_relation_1" require data-class="reserve1-relation" class="form-select" data-class="academic-status" >
									<option value="" selected>اختار</option>
									<option value="الوالد">الوالد</option>
									<option value="الوالدة">الوالدة</option>
									<option value="أخ">أخ			</option>
									<option value="أخت">أخت			</option>
									<option value="عمـ/ـة" >عمـ/ـة	</option>
									<option value="خالـ/ـة" >خالـ/ـة</option>
									<option value="جد/ة"> جد/ة		</option>
									<option value="أخرى"> أخرى		</option>
								</select>
								<i class="fa-solid fa-star required-inputs"></i>
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">الجوال</label>
								<input name="reserve_relation_phone_1" require data-class="reserve1-phone"     type="number" placeholder="********05"  class="form-control"    >
								<i class="fa-solid fa-star required-inputs"></i>
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">الاسم الثاني</label>
								<input name="reserve_name_2" data-class="reserve2-name"   type="text"  class="form-control"    >
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">صلة القرابة</label>
								<select name="reserve_relation_2" data-class="reserve2-relation" class="form-select" data-class="academic-status" >
									<option value="" >اختار</option>
									<option value="الوالد" selected>الوالد</option>
									<option value="الوالدة">الوالدة</option>
									<option value="أخ">أخ			</option>
									<option value="أخت">أخت			</option>
									<option value="عمـ/ـة" >عمـ/ـة	</option>
									<option value="خالـ/ـة" >خالـ/ـة</option>
									<option value="جد/ة"> جد/ة		</option>
									<option value="أخرى"> أخرى		</option>
								</select>
							</div>

							<div class="input-group mb-3 gap-1">
								<label class=" bg-label" for="">الجوال</label>
								<input name="reserve_relation_phone_2" data-class="reserve2-phone"   type="number" placeholder="********05"  class="form-control"    >
							</div>


						</div>
					</article>

					<div class="tow-col imgs-contracts">
						<div class="input-group mb-3 gap-1">
							<label class=" bg-label" for="img_4">صورة الهوية</label>
							<input name="img_1" type="file" class="form-control" id="img_1" >
						</div>

					</div> <!-- container imgs -->
				</div>
				<div class="form-registration">
					<div class="tow-col submit-btns-container mt-5">
						<!-- <button class="btn btn-primary show-contract"> <i class="fa-solid fa-eye"></i> مشاهدة العقد   </button> -->
						<!-- <div class="btn btn-primary btn-print"  > <i class="fa-solid fa-print"></i> طباعة العقد  </div> -->
						<input class="btn btn-primary submit-btn" type="submit" value="تسجيل ">
					</div>
			    </div>
				</form>
			</div>
              		
		</main>
		<!-- Start Calender  -->
		<link rel="stylesheet" type="text/css" href="./LIB/calender/ummalqura.calendars.picker.css" />
		<script type="text/javascript" src="./LIB/calender/jquery-3.6.1.min.js"></script>
		<script type="text/javascript" src="./LIB/calender/jquery.calendars.js"></script>
		<script type="text/javascript" src="./LIB/calender/jquery.plugin.js"></script>
		<script type="text/javascript" src="./LIB/calender/jquery.calendars.plus.js"></script>
		<script type="text/javascript" src="./LIB/calender/jquery.calendars.picker.js"></script>
		<script type="text/javascript" src="./LIB/calender/jquery.calendars.picker-ar.js"></script>
		<script type="text/javascript" src="./LIB/calender/jquery.calendars.ummalqura.js"></script>
		<script type="text/javascript" src="./LIB/calender/jquery.calendars.ummalqura-ar.js"></script>
		<script type="text/javascript" src="./LIB/calender/calendar-convert.js"></script>
		<script type="text/javascript" src="./LIB/calender/sss.js"></script>
		<!-- End Calender  -->
		<script src="./assets/js/bootstrap.min.js"></script>
		<script src="./assets/js/select.js"></script>
		<script src="./assets/js/main.js"></script>
		      
	</body>
</html>